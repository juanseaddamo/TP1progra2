package EJ1;

public class ejemplo1 {
    private int x = 5;
}
