package org.example.adt;
import org.example.utils.Ejercicio1Utils;
import org.example.utils.QueueOfStacksUtils;

import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        Queue<Stack> matrix = new LinkedList<>();

        // Create the original 3x3 matrix using StaticStacks
        StaticStack stack1 = new StaticStack(3);
        stack1.add(1);
        stack1.add(4);
        stack1.add(7);

        StaticStack stack2 = new StaticStack(3);
        stack2.add(2);
        stack2.add(5);
        stack2.add(8);

        StaticStack stack3 = new StaticStack(3);
        stack3.add(3);
        stack3.add(6);
        stack3.add(9);

        // Add the stacks to the matrix (queue of stacks)
        matrix.add(stack1);
        matrix.add(stack2);
        matrix.add(stack3);

        // Calculate and print the trace of the matrix
        int trace = QueueOfStacksUtils.calculateTrace(matrix);
        System.out.println("Trace of the matrix: " + trace);  // Should print 15 (1 + 5 + 9)

        // Transpose the matrix and print the result

    }
}

