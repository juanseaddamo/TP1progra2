package org.example.adt;

public interface Queue {

    int getFirst();
    void remove();
    void add(int value);
    boolean isEmpty();
}
