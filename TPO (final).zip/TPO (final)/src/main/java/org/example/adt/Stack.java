package org.example.adt;

public interface Stack {

    int getTop();
    void remove();
    void add(int value);
    boolean isEmpty();

}

