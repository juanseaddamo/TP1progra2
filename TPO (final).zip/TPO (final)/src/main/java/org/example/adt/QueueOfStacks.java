package org.example.adt;


import java.util.LinkedList;

public class QueueOfStacks {
    private Queue<StaticStack> queue;

    public QueueOfStacks() {
        queue = new LinkedList<>();
    }

    public void add(StaticStack stack) {
        queue.add(stack);
    }

    public StaticStack remove() {
        return queue.remove();
    }

    public StaticStack getFirst() {
        return queue.this.array();  // Devuelve el primer elemento sin eliminarlo
    }

    public int size() {
        return queue.size();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

}
