package org.example.utils;

import org.example.adt.QueueOfStacks;
import org.example.adt.Stack;

public class QueueOfStacksUtils {
    
    public QueueOfStacks transpose(QueueOfStacks original) {
        // Si la cola original está vacía, retornamos una transpuesta vacía
        if (original.isEmpty()) {
            return new QueueOfStacks();
        }

        // Creamos una cola temporal para preservar el original y contar el número de pilas
        QueueOfStacks tempQueue = new QueueOfStacks();
        int numStacks = 0;

        while (!original.isEmpty()) {
            Stack currentStack = original.getFirst();
            tempQueue.add(currentStack);
            original.remove();
            numStacks++;
        }

        // Restaurar la estructura original
        while (!tempQueue.isEmpty()) {
            original.add(tempQueue.getFirst());
            tempQueue.remove();
        }

        // Calculamos el número de elementos en cada pila
        int elementsPerStack = original.getFirst().size();

        // Creamos una nueva cola de pilas para la transpuesta
        QueueOfStacks transposed = new QueueOfStacks();

        // Añadimos pilas vacías a la transpuesta, una por cada elemento por pila
        for (int i = 0; i < elementsPerStack; i++) {
            transposed.add(new Stack());  // Añadimos pilas vacías a la transpuesta
        }

        // Transposición: iteramos sobre cada pila en la cola original
        for (int i = 0; i < numStacks; i++) {
            Stack currentStack = original.getFirst();  // Obtenemos la pila actual
            original.remove();  // La eliminamos de la cola original temporalmente

            // Ahora colocamos los elementos en las pilas correspondientes de la transpuesta
            for (int j = 0; j < elementsPerStack; j++) {
                int element = currentStack.getTop();  // Obtenemos el elemento de la pila
                currentStack.remove();  // Lo eliminamos de la pila original

                // Extraemos las pilas de la transpuesta temporalmente
                Stack transposedStack = transposed.getFirst();  // Tomamos la primera pila de la transpuesta
                transposed.remove();  // La removemos temporalmente de la cola transpuesta

                transposedStack.add(element);  // Añadimos el elemento a la pila correspondiente
                transposed.add(transposedStack);  // Volvemos a colocar la pila en la cola transpuesta
            }

            // Restauramos la pila original en la cola
            original.add(currentStack);
        }

        return transposed;
    }

}