package org.example.utils;

import org.example.adt.StaticStack;

import java.util.LinkedList;
import java.util.Queue;


public class Ejercicio1Utils {
    public static int calculateTrace(Queue<StaticStack> matrix) {
        int trace = 0;
        int columnIndex = 0;

        // Iterate over the queue of stacks (matrix columns)
        for (StaticStack stack : matrix) {
            // Simulate extracting the columnIndex-th element from the stack
            StaticStack temp = new StaticStack(stack.size());
            int value = 0;

            // Remove elements until we reach the diagonal element (columnIndex-th element)
            for (int i = 0; i <= columnIndex && !stack.isEmpty(); i++) {
                value = stack.getTop();  // Get the top element
                stack.remove();          // Remove the top element

                // Store non-diagonal elements in a temporary stack
                if (i < columnIndex) {
                    temp.add(value);
                }
            }

            // Restore the elements back to the original stack
            while (!temp.isEmpty()) {
                stack.add(temp.getTop());
                temp.remove();
            }

            // Add the diagonal element to the trace sum
            trace += value;
            columnIndex++;
        }

        return trace;
    }

    // 2. Transpose the matrix (switch rows with columns)
    public static Queue<StaticStack> transpose(Queue<StaticStack> matrix) {
        int numStacks = matrix.size();  // Number of columns in the original matrix
        int stackSize = matrix.element().size();  // Size of each stack (number of rows)

        // Step 1: Initialize a queue of queues to collect elements row by row
        Queue<Queue<Integer>> rowQueue = new LinkedList<>();
        for (int i = 0; i < stackSize; i++) {
            rowQueue.add(new LinkedList<>());  // Each inner queue represents a row
        }

        // Step 2: Transfer elements from each stack (column) into row queues
        for (StaticStack column : matrix) {
            StaticStack tempStack = new StaticStack(stackSize);

            // Reverse the order of the stack into a temporary stack to preserve order
            while (!column.isEmpty()) {
                tempStack.add(column.getTop());
                column.remove();
            }

            // Now distribute the reversed elements into the appropriate row queues
            int row = 0;
            while (!tempStack.isEmpty()) {
                int value = tempStack.getTop();
                tempStack.remove();

                // Add the element to the correct row queue
                getNthQueue(rowQueue, row).add(value);
                row++;
            }
        }

        // Step 3: Convert the row queues back into stacks for the transposed matrix
        Queue<StaticStack> transposedMatrix = new LinkedList<>();
        for (Queue<Integer> row : rowQueue) {
            StaticStack newStack = new StaticStack(numStacks);
            while (!row.isEmpty()) {
                newStack.add(row.remove());
            }
            transposedMatrix.add(newStack);
        }

        return transposedMatrix;
    }

    // Helper function to get the nth queue from a queue of queues
    private static Queue<Integer> getNthQueue(Queue<Queue<Integer>> queue, int n) {
        int index = 0;
        for (Queue<Integer> q : queue) {
            if (index == n) return q;
            index++;
        }
        throw new IllegalArgumentException("Invalid index: " + n);
    }

    // 3. Add two matrices element-wise
    public static Queue<StaticStack> addMatrices(Queue<StaticStack> m1, Queue<StaticStack> m2) {
        Queue<StaticStack> sumMatrix = new LinkedList<>();

        // Create temporary queues to preserve the original matrices
        Queue<StaticStack> m1Copy = new LinkedList<>(m1);
        Queue<StaticStack> m2Copy = new LinkedList<>(m2);

        // Iterate over both matrices and add corresponding stacks
        while (!m1Copy.isEmpty() && !m2Copy.isEmpty()) {
            StaticStack stack1 = m1Copy.remove(); // Get the front stack
            StaticStack stack2 = m2Copy.remove(); // Get the front stack

            // Create a new stack to hold the sum of the current row
            StaticStack sumStack = new StaticStack(stack1.size());

            // Temporary stacks to hold values for restoration
            StaticStack temp1 = new StaticStack(stack1.size());
            StaticStack temp2 = new StaticStack(stack2.size());

            // Add corresponding elements from both stacks
            while (!stack1.isEmpty() && !stack2.isEmpty()) {
                // Store the top elements to sum them
                int value1 = stack1.getTop();
                int value2 = stack2.getTop();
                int sum = value1 + value2;
                sumStack.add(sum);

                // Store elements temporarily to restore the original stacks
                temp1.add(value1);
                temp2.add(value2);

                stack1.remove();
                stack2.remove();
            }

            // Restore original stacks
            while (!temp1.isEmpty()) {
                stack1.add(temp1.getTop());
                temp1.remove();
            }
            while (!temp2.isEmpty()) {
                stack2.add(temp2.getTop());
                temp2.remove();
            }

            // Add the sum stack to the sum matrix
            sumMatrix.add(sumStack);
        }

        return sumMatrix;
    }

}
